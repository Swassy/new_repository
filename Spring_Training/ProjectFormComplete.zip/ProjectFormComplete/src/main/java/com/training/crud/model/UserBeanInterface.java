package com.training.crud.model;

public interface UserBeanInterface {
	
	public void setEmail(String email);
	public void setPassword(String password);
	public String getEmail();
	public String getPassword();
	

}
